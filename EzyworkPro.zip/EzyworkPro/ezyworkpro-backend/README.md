# EzyWorkPro Backend (Laravel 11)

This repository contains a scaffold for the EzyWorkPro enterprise workforce management backend.

Core features implemented:
- Authentication (Laravel Breeze / Sanctum recommended for API tokens)
- Role-based access (Admin, Employee)
- Staff management
- Attendance tracking
- Leave management
- Shift management
- Payroll automation (scheduled)
- KPIs and activity logs
- Notifications (database + mail)
- Reports for admin dashboard

Quick setup (after cloning):

1. Install dependencies

```powershell
composer install
cp .env.example .env
php artisan key:generate
# set DB credentials in .env
php artisan migrate --seed
composer require laravel/breeze --dev
php artisan breeze:install api
php artisan migrate
```

2. Use Laravel Sanctum for API tokens (recommended for SPA/mobile)

3. Register an admin user via seeder or API endpoint and begin using endpoints in `routes/api.php`.

Notes:
- This repository is scaffolded programmatically. After installing dependencies, review and adapt middleware (auth guard), mail and queue settings, and any business rules.
