<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\Shift;

class ShiftAssignedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $shift;
    protected $date;

    public function __construct(Shift $shift, $date)
    {
        $this->shift = $shift;
        $this->date = $date;
    }

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('New Shift Assignment')
            ->line("You have been assigned to a new shift.")
            ->line("Shift: {$this->shift->name}")
            ->line("Date: {$this->date}")
            ->line("Time: {$this->shift->start_time} to {$this->shift->end_time}")
            ->action('View Schedule', url('/dashboard/shifts'));
    }

    public function toArray($notifiable)
    {
        return [
            'shift_id' => $this->shift->id,
            'shift_name' => $this->shift->name,
            'date' => $this->date,
            'start_time' => $this->shift->start_time,
            'end_time' => $this->shift->end_time,
        ];
    }
}