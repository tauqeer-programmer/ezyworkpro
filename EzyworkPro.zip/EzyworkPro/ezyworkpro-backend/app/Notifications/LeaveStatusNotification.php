<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\Leave;

class LeaveStatusNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $leave;

    public function __construct(Leave $leave)
    {
        $this->leave = $leave;
    }

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        $status = ucfirst($this->leave->status);
        return (new MailMessage)
            ->subject("Leave Request {$status}")
            ->line("Your leave request has been {$this->leave->status}.")
            ->line("Type: {$this->leave->type}")
            ->line("From: {$this->leave->start_date->format('Y-m-d')}")
            ->line("To: {$this->leave->end_date->format('Y-m-d')}")
            ->action('View Details', url('/dashboard/leaves/' . $this->leave->id));
    }

    public function toArray($notifiable)
    {
        return [
            'leave_id' => $this->leave->id,
            'status' => $this->leave->status,
            'type' => $this->leave->type,
            'start_date' => $this->leave->start_date,
            'end_date' => $this->leave->end_date,
        ];
    }
}