<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\Payroll;

class PayrollGeneratedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $payroll;

    public function __construct(Payroll $payroll)
    {
        $this->payroll = $payroll;
    }

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Payroll Generated')
            ->line('Your payroll for the period has been generated.')
            ->line("Period: {$this->payroll->period_start->format('Y-m-d')} to {$this->payroll->period_end->format('Y-m-d')}")
            ->line("Gross Salary: {$this->payroll->gross_salary}")
            ->line("Deductions: {$this->payroll->deductions}")
            ->line("Net Salary: {$this->payroll->net_salary}")
            ->action('View Details', url('/dashboard/payroll/' . $this->payroll->id));
    }

    public function toArray($notifiable)
    {
        return [
            'payroll_id' => $this->payroll->id,
            'period_start' => $this->payroll->period_start,
            'period_end' => $this->payroll->period_end,
            'net_salary' => $this->payroll->net_salary,
        ];
    }
}