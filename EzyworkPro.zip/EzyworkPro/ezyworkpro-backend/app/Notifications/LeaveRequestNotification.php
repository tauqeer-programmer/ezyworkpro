<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\Leave;

class LeaveRequestNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $leave;

    public function __construct(Leave $leave)
    {
        $this->leave = $leave;
    }

    public function via($notifiable)
    {
        return ['mail', 'database'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('New Leave Request')
            ->line("Employee {$this->leave->user->name} has submitted a leave request.")
            ->line("Type: {$this->leave->type}")
            ->line("From: {$this->leave->start_date->format('Y-m-d')}")
            ->line("To: {$this->leave->end_date->format('Y-m-d')}")
            ->line("Reason: {$this->leave->reason}")
            ->action('Review Request', url('/dashboard/leaves/' . $this->leave->id));
    }

    public function toArray($notifiable)
    {
        return [
            'leave_id' => $this->leave->id,
            'user_name' => $this->leave->user->name,
            'type' => $this->leave->type,
            'start_date' => $this->leave->start_date,
            'end_date' => $this->leave->end_date,
        ];
    }
}