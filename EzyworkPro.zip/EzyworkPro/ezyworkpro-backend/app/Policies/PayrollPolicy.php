<?php

namespace App\Policies;

use App\Models\Payroll;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PayrollPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return $user->role === 'admin';
    }

    public function view(User $user, Payroll $payroll)
    {
        return $user->role === 'admin' || $user->id === $payroll->user_id;
    }

    public function create(User $user)
    {
        return $user->role === 'admin';
    }

    public function update(User $user, Payroll $payroll)
    {
        return $user->role === 'admin';
    }

    public function delete(User $user, Payroll $payroll)
    {
        return $user->role === 'admin';
    }
}