<?php

namespace App\Policies;

use App\Models\Kpi;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class KpiPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return true;
    }

    public function view(User $user, Kpi $kpi)
    {
        return $user->role === 'admin' || $user->id === $kpi->user_id;
    }

    public function create(User $user)
    {
        return true;
    }

    public function update(User $user, Kpi $kpi)
    {
        return $user->role === 'admin';
    }

    public function delete(User $user, Kpi $kpi)
    {
        return $user->role === 'admin';
    }
}