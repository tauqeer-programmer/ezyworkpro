<?php

namespace App\Policies;

use App\Models\Leave;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LeavePolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return true;
    }

    public function view(User $user, Leave $leave)
    {
        return $user->role === 'admin' || $user->id === $leave->user_id;
    }

    public function create(User $user)
    {
        return true;
    }

    public function update(User $user, Leave $leave)
    {
        // Admin can update any leave, users can only update their pending leaves
        return $user->role === 'admin' || 
            ($user->id === $leave->user_id && $leave->status === 'pending');
    }

    public function delete(User $user, Leave $leave)
    {
        return $user->role === 'admin' || 
            ($user->id === $leave->user_id && $leave->status === 'pending');
    }

    public function approve(User $user, Leave $leave)
    {
        return $user->role === 'admin';
    }
}