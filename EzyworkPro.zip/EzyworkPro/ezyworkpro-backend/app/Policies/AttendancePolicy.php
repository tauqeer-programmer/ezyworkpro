<?php

namespace App\Policies;

use App\Models\Attendance;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AttendancePolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return true;
    }

    public function view(User $user, Attendance $attendance)
    {
        return $user->role === 'admin' || $user->id === $attendance->user_id;
    }

    public function create(User $user)
    {
        return true;
    }

    public function update(User $user, Attendance $attendance)
    {
        return $user->role === 'admin';
    }

    public function delete(User $user, Attendance $attendance)
    {
        return $user->role === 'admin';
    }
}