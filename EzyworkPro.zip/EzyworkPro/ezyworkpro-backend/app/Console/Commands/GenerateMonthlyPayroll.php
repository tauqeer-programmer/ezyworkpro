<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Payroll;
use App\Models\User;
use App\Models\Attendance;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use App\Notifications\PayrollGeneratedNotification;

class GenerateMonthlyPayroll extends Command
{
    protected $signature = 'payroll:generate {--month=} {--year=}';
    protected $description = 'Generate monthly payroll for all employees';

    public function handle()
    {
        $month = $this->option('month') ?? now()->subMonth()->month;
        $year = $this->option('year') ?? now()->year;

        $start = Carbon::create($year, $month, 1)->startOfMonth();
        $end = $start->copy()->endOfMonth();

        $this->info("Generating payroll for period: {$start->format('Y-m-d')} to {$end->format('Y-m-d')}");

        $users = User::where('role', 'employee')->get();
        $count = 0;

        foreach ($users as $user) {
            try {
                // Calculate worked hours for the month
                $attendances = Attendance::where('user_id', $user->id)
                    ->whereBetween('date', [$start, $end])
                    ->where('status', 'closed')
                    ->get();

                $totalHours = $attendances->sum('hours');
                $overtimeHours = max(0, $totalHours - 160);
                $regularHours = min($totalHours, 160);

                // Calculate salary
                $regularPay = $regularHours * $user->hourly_rate;
                $overtimePay = $overtimeHours * ($user->hourly_rate * 1.5);
                $grossSalary = $regularPay + $overtimePay;
                $deductions = $grossSalary * 0.1; // 10% standard deductions
                $netSalary = $grossSalary - $deductions;

                $payroll = Payroll::create([
                    'user_id' => $user->id,
                    'period_start' => $start,
                    'period_end' => $end,
                    'gross_salary' => $grossSalary,
                    'deductions' => $deductions,
                    'overtime_pay' => $overtimePay,
                    'net_salary' => $netSalary,
                    'status' => 'pending'
                ]);

                // Notify user of payroll generation
                $user->notify(new PayrollGeneratedNotification($payroll));
                $count++;

            } catch (\Exception $e) {
                Log::error("Failed to generate payroll for user {$user->id}: " . $e->getMessage());
                $this->error("Failed to generate payroll for {$user->name}");
            }
        }

        $this->info("Successfully generated {$count} payroll records");
    }
}