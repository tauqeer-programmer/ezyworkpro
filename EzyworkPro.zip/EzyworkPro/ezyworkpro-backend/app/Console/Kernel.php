<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        Commands\GenerateMonthlyPayroll::class,
    ];

    protected function schedule(Schedule $schedule)
    {
        // Close open attendances at midnight
        $schedule->command('attendance:close-day')
            ->dailyAt('23:59');

        // Generate monthly payroll on last day of month
        $schedule->command('payroll:generate')
            ->monthlyOn(date('t'), '23:00');

        // Calculate KPIs daily
        $schedule->command('kpi:calculate')
            ->dailyAt('00:01');

        // Sync department statistics weekly
        $schedule->command('department:sync-stats')
            ->weekly();
    }

    protected function commands()
    {
        $this->load(__DIR__.'/Commands');
        require base_path('routes/console.php');
    }
}