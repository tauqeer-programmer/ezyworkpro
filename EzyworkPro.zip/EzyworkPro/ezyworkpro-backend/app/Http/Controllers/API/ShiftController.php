<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Shift;
use App\Http\Requests\ShiftRequest;
use App\Http\Requests\ShiftAssignRequest;
use Illuminate\Http\Request;

class ShiftController extends Controller
{
    public function index(Request $request)
    {
        $query = Shift::with('users');
        
        if ($request->has('date')) {
            $query->whereHas('users', function($q) use ($request) {
                $q->where('date', $request->date);
            });
        }

        return $query->paginate(20);
    }

    public function store(ShiftRequest $request)
    {
        $shift = Shift::create($request->validated());
        return response()->json($shift, 201);
    }

    public function show(Shift $shift)
    {
        return $shift->load(['users' => function($query) {
            $query->orderBy('shift_user.date');
        }]);
    }

    public function update(ShiftRequest $request, Shift $shift)
    {
        $shift->update($request->validated());
        return response()->json($shift);
    }

    public function destroy(Shift $shift)
    {
        $shift->delete();
        return response()->json(['message' => 'Deleted']);
    }

    public function assign(ShiftAssignRequest $request, Shift $shift)
    {
        $data = $request->validated();
        
        // Attach users to shift with date
        foreach ($data['user_ids'] as $userId) {
            $shift->users()->attach($userId, ['date' => $data['date']]);
        }

        return response()->json(['message' => 'Users assigned to shift']);
    }

    public function unassign(Request $request, Shift $shift)
    {
        $request->validate([
            'user_ids' => 'required|array',
            'user_ids.*' => 'exists:users,id',
            'date' => 'required|date'
        ]);

        $shift->users()->wherePivot('date', $request->date)
            ->whereIn('users.id', $request->user_ids)
            ->detach();

        return response()->json(['message' => 'Users unassigned from shift']);
    }

    public function myShifts(Request $request)
    {
        $shifts = $request->user()->shifts()
            ->wherePivot('date', '>=', now()->toDateString())
            ->orderBy('shift_user.date')
            ->get();

        return response()->json($shifts);
    }
}