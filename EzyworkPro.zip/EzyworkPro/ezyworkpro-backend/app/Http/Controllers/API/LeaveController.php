<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Leave;
use App\Http\Requests\LeaveRequest;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use App\Notifications\LeaveRequestNotification;
use App\Notifications\LeaveStatusNotification;

class LeaveController extends Controller
{
    public function index(Request $request)
    {
        $query = Leave::with(['user', 'approver']);
        
        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        return $query->orderBy('created_at', 'desc')->paginate(20);
    }

    public function store(LeaveRequest $request)
    {
        $data = $request->validated();
        $data['user_id'] = $request->user()->id;
        $data['days'] = Carbon::parse($data['start_date'])->diffInDays(Carbon::parse($data['end_date'])) + 1;
        
        $leave = Leave::create($data);

        // Notify admin of new leave request
        $admins = \App\Models\User::where('role', 'admin')->get();
        Notification::send($admins, new LeaveRequestNotification($leave));

        return response()->json($leave, 201);
    }

    public function show(Leave $leave)
    {
        $this->authorize('view', $leave);
        return $leave->load(['user', 'approver']);
    }

    public function update(LeaveRequest $request, Leave $leave)
    {
        $this->authorize('update', $leave);
        
        $data = $request->validated();
        if (isset($data['status']) && $request->user()->role === 'admin') {
            $data['approved_by'] = $request->user()->id;
            
            // Notify employee of leave status change
            $leave->user->notify(new LeaveStatusNotification($leave));
        }

        $leave->update($data);
        return response()->json($leave);
    }

    public function destroy(Leave $leave)
    {
        $this->authorize('delete', $leave);
        $leave->delete();
        return response()->json(['message' => 'Deleted']);
    }
}