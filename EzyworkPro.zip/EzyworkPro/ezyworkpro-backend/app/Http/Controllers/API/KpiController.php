<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Kpi;
use App\Http\Requests\KpiRequest;
use Illuminate\Http\Request;

class KpiController extends Controller
{
    public function index(Request $request)
    {
        $query = Kpi::with('user');
        
        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        if ($request->has(['from_date', 'to_date'])) {
            $query->whereBetween('date', [$request->from_date, $request->to_date]);
        }

        if ($request->has('metric')) {
            $query->where('metric', $request->metric);
        }

        return $query->orderBy('date', 'desc')->paginate(20);
    }

    public function store(KpiRequest $request)
    {
        $data = $request->validated();
        
        if ($request->user()->role !== 'admin') {
            $data['user_id'] = $request->user()->id;
        }

        $kpi = Kpi::create($data);
        return response()->json($kpi, 201);
    }

    public function show(Kpi $kpi)
    {
        $this->authorize('view', $kpi);
        return $kpi->load('user');
    }

    public function update(KpiRequest $request, Kpi $kpi)
    {
        $this->authorize('update', $kpi);
        $kpi->update($request->validated());
        return response()->json($kpi);
    }

    public function destroy(Kpi $kpi)
    {
        $this->authorize('delete', $kpi);
        $kpi->delete();
        return response()->json(['message' => 'Deleted']);
    }

    public function summary(Request $request)
    {
        $request->validate([
            'user_id' => 'nullable|exists:users,id',
            'from_date' => 'required|date',
            'to_date' => 'required|date|after:from_date',
        ]);

        $query = Kpi::query();

        if ($request->has('user_id')) {
            $query->where('user_id', $request->user_id);
        } elseif ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        $summary = $query->whereBetween('date', [$request->from_date, $request->to_date])
            ->select('metric')
            ->selectRaw('AVG(value) as average_value')
            ->selectRaw('AVG(target) as average_target')
            ->groupBy('metric')
            ->get();

        return response()->json($summary);
    }
}