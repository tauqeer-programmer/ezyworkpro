<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Http\Requests\AttendanceRequest;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function index(Request $request)
    {
        $query = Attendance::with('user');
        
        // Filter by date range if provided
        if ($request->has('from_date') && $request->has('to_date')) {
            $query->whereBetween('date', [$request->from_date, $request->to_date]);
        }
        
        // If not admin, show only own attendance
        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        return $query->orderBy('date', 'desc')->paginate(20);
    }

    public function clockIn(Request $request)
    {
        $now = Carbon::now();
        $today = $now->toDateString();
        
        // Check if already clocked in today
        $attendance = Attendance::where('user_id', $request->user()->id)
            ->where('date', $today)
            ->first();
            
        if ($attendance && $attendance->clock_in) {
            return response()->json(['message' => 'Already clocked in today'], 400);
        }

        $attendance = Attendance::create([
            'user_id' => $request->user()->id,
            'date' => $today,
            'clock_in' => $now,
            'status' => 'open'
        ]);

        return response()->json($attendance, 201);
    }

    public function clockOut(Request $request)
    {
        $now = Carbon::now();
        $today = $now->toDateString();
        
        $attendance = Attendance::where('user_id', $request->user()->id)
            ->where('date', $today)
            ->where('status', 'open')
            ->first();
            
        if (!$attendance) {
            return response()->json(['message' => 'No open attendance found for today'], 404);
        }

        if ($attendance->clock_out) {
            return response()->json(['message' => 'Already clocked out'], 400);
        }

        $hours = $now->diffInHours($attendance->clock_in);
        
        $attendance->update([
            'clock_out' => $now,
            'hours' => $hours,
            'status' => 'closed'
        ]);

        return response()->json($attendance);
    }

    public function show(Attendance $attendance)
    {
        $this->authorize('view', $attendance);
        return $attendance->load('user');
    }

    public function update(AttendanceRequest $request, Attendance $attendance)
    {
        $this->authorize('update', $attendance);
        $attendance->update($request->validated());
        return response()->json($attendance);
    }
}