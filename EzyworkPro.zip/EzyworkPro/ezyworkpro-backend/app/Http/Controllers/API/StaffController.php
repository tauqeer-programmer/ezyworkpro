<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Department;
use App\Http\Requests\StaffRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class StaffController extends Controller
{
    public function index()
    {
        return User::with('department')->paginate(20);
    }

    public function store(StaffRequest $request)
    {
        $data = $request->validated();
        $data['password'] = Hash::make($data['password']);
        $user = User::create($data);
        return response()->json($user, 201);
    }

    public function show(User $staff)
    {
        return $staff->load('department');
    }

    public function update(StaffRequest $request, User $staff)
    {
        $data = $request->validated();
        if (isset($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        }
        $staff->update($data);
        return response()->json($staff);
    }

    public function destroy(User $staff)
    {
        $staff->delete();
        return response()->json(['message' => 'Deleted']);
    }
}
