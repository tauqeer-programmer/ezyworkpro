<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Attendance;
use App\Models\Leave;
use App\Models\Payroll;
use App\Models\Kpi;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function dashboard(Request $request)
    {
        $this->authorize('viewAny', User::class);

        $today = Carbon::today();
        $startOfMonth = $today->copy()->startOfMonth();
        $endOfMonth = $today->copy()->endOfMonth();

        $stats = [
            'total_employees' => User::where('role', 'employee')->count(),
            'departments' => DB::table('departments')
                ->select('departments.name', DB::raw('COUNT(users.id) as employee_count'))
                ->leftJoin('users', 'departments.id', '=', 'users.department_id')
                ->groupBy('departments.id', 'departments.name')
                ->get(),
            'attendance' => [
                'present_today' => Attendance::whereDate('date', $today)
                    ->where('status', 'open')
                    ->count(),
                'absent_today' => User::where('role', 'employee')->count() - 
                    Attendance::whereDate('date', $today)->count(),
                'monthly_hours' => Attendance::whereBetween('date', [$startOfMonth, $endOfMonth])
                    ->sum('hours'),
            ],
            'leaves' => [
                'pending' => Leave::where('status', 'pending')->count(),
                'approved' => Leave::whereBetween('start_date', [$startOfMonth, $endOfMonth])
                    ->where('status', 'approved')
                    ->count(),
                'by_type' => Leave::select('type', DB::raw('COUNT(*) as count'))
                    ->whereBetween('start_date', [$startOfMonth, $endOfMonth])
                    ->groupBy('type')
                    ->get(),
            ],
            'payroll' => [
                'monthly_total' => Payroll::whereBetween('period_start', [$startOfMonth, $endOfMonth])
                    ->sum('net_salary'),
                'pending_payments' => Payroll::where('status', 'pending')->count(),
                'overtime_cost' => Payroll::whereBetween('period_start', [$startOfMonth, $endOfMonth])
                    ->sum('overtime_pay'),
            ],
            'kpis' => [
                'metrics' => Kpi::select('metric', 
                    DB::raw('AVG(value) as average_value'),
                    DB::raw('AVG(target) as average_target'))
                    ->whereBetween('date', [$startOfMonth, $endOfMonth])
                    ->groupBy('metric')
                    ->get(),
            ],
        ];

        return response()->json($stats);
    }

    public function attendanceReport(Request $request)
    {
        $this->authorize('viewAny', Attendance::class);

        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after:from_date',
            'department_id' => 'nullable|exists:departments,id',
        ]);

        $query = Attendance::with('user')
            ->whereBetween('date', [$request->from_date, $request->to_date]);

        if ($request->has('department_id')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('department_id', $request->department_id);
            });
        }

        $report = $query->select(
                'user_id',
                DB::raw('COUNT(*) as total_days'),
                DB::raw('SUM(hours) as total_hours'),
                DB::raw('AVG(hours) as average_hours'),
                DB::raw('COUNT(CASE WHEN status = "missing" THEN 1 END) as absences')
            )
            ->groupBy('user_id')
            ->get();

        return response()->json($report);
    }

    public function payrollReport(Request $request)
    {
        $this->authorize('viewAny', Payroll::class);

        $request->validate([
            'year' => 'required|integer|min:2000|max:2099',
            'month' => 'required|integer|min:1|max:12',
        ]);

        $date = Carbon::create($request->year, $request->month, 1);
        $startOfMonth = $date->copy()->startOfMonth();
        $endOfMonth = $date->copy()->endOfMonth();

        $report = Payroll::with('user')
            ->whereBetween('period_start', [$startOfMonth, $endOfMonth])
            ->select(
                'department_id',
                DB::raw('COUNT(DISTINCT user_id) as employee_count'),
                DB::raw('SUM(gross_salary) as total_gross'),
                DB::raw('SUM(deductions) as total_deductions'),
                DB::raw('SUM(overtime_pay) as total_overtime'),
                DB::raw('SUM(net_salary) as total_net')
            )
            ->join('users', 'payrolls.user_id', '=', 'users.id')
            ->groupBy('department_id')
            ->get();

        return response()->json($report);
    }

    public function performanceReport(Request $request)
    {
        $this->authorize('viewAny', Kpi::class);

        $request->validate([
            'from_date' => 'required|date',
            'to_date' => 'required|date|after:from_date',
            'department_id' => 'nullable|exists:departments,id',
        ]);

        $query = Kpi::with('user')
            ->whereBetween('date', [$request->from_date, $request->to_date]);

        if ($request->has('department_id')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('department_id', $request->department_id);
            });
        }

        $report = $query->select(
                'user_id',
                'metric',
                DB::raw('AVG(value) as average_value'),
                DB::raw('AVG(target) as average_target'),
                DB::raw('MIN(value) as min_value'),
                DB::raw('MAX(value) as max_value')
            )
            ->groupBy('user_id', 'metric')
            ->get();

        return response()->json($report);
    }
}