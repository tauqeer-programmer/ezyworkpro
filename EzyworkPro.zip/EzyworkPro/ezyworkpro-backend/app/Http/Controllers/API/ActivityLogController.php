<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Http\Requests\ActivityLogRequest;
use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    public function index(Request $request)
    {
        $query = ActivityLog::with('user');
        
        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        if ($request->has(['from_date', 'to_date'])) {
            $query->whereBetween('performed_at', [$request->from_date, $request->to_date]);
        }

        if ($request->has('action')) {
            $query->where('action', $request->action);
        }

        return $query->orderBy('performed_at', 'desc')->paginate(20);
    }

    public function store(ActivityLogRequest $request)
    {
        $data = $request->validated();
        $data['user_id'] = $request->user()->id;
        $data['performed_at'] = now();

        $log = ActivityLog::create($data);
        return response()->json($log, 201);
    }

    public function show(ActivityLog $log)
    {
        $this->authorize('view', $log);
        return $log->load('user');
    }

    public function userActivity(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'from_date' => 'required|date',
            'to_date' => 'required|date|after:from_date',
        ]);

        $activities = ActivityLog::where('user_id', $request->user_id)
            ->whereBetween('performed_at', [$request->from_date, $request->to_date])
            ->orderBy('performed_at', 'desc')
            ->get();

        return response()->json($activities);
    }

    public function dailySummary(Request $request)
    {
        $request->validate([
            'date' => 'required|date',
        ]);

        $query = ActivityLog::with('user')
            ->whereDate('performed_at', $request->date);

        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        $summary = $query->select('action')
            ->selectRaw('COUNT(*) as count')
            ->groupBy('action')
            ->get();

        return response()->json($summary);
    }
}