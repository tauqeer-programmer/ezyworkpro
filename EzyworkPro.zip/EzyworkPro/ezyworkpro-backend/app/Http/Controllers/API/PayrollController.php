<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Payroll;
use App\Models\User;
use App\Models\Attendance;
use App\Http\Requests\PayrollRequest;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PayrollController extends Controller
{
    public function index(Request $request)
    {
        $query = Payroll::with('user');

        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }

        if ($request->has(['from_date', 'to_date'])) {
            $query->whereBetween('period_start', [$request->from_date, $request->to_date]);
        }

        return $query->orderBy('period_start', 'desc')->paginate(20);
    }

    public function show(Payroll $payroll)
    {
        $this->authorize('view', $payroll);
        return $payroll->load('user');
    }

    public function update(PayrollRequest $request, Payroll $payroll)
    {
        $this->authorize('update', $payroll);
        $payroll->update($request->validated());
        return response()->json($payroll);
    }

    public function runPayroll(Request $request)
    {
        $request->validate([
            'period_start' => 'required|date',
            'period_end' => 'required|date|after:period_start',
        ]);

        $start = Carbon::parse($request->period_start);
        $end = Carbon::parse($request->period_end);

        $users = User::where('role', 'employee')->get();
        $payrolls = [];

        foreach ($users as $user) {
            // Calculate worked hours
            $attendances = Attendance::where('user_id', $user->id)
                ->whereBetween('date', [$start, $end])
                ->where('status', 'closed')
                ->get();

            $totalHours = $attendances->sum('hours');
            $overtimeHours = max(0, $totalHours - 160); // Assuming 160 hours is standard monthly
            $regularHours = min($totalHours, 160);

            // Calculate salary components
            $regularPay = $regularHours * $user->hourly_rate;
            $overtimePay = $overtimeHours * ($user->hourly_rate * 1.5); // 1.5x for overtime
            $grossSalary = $regularPay + $overtimePay;
            
            // Standard deductions (example: 10% for taxes and benefits)
            $deductions = $grossSalary * 0.1;
            $netSalary = $grossSalary - $deductions;

            $payroll = Payroll::create([
                'user_id' => $user->id,
                'period_start' => $start,
                'period_end' => $end,
                'gross_salary' => $grossSalary,
                'deductions' => $deductions,
                'overtime_pay' => $overtimePay,
                'net_salary' => $netSalary,
                'status' => 'pending'
            ]);

            $payrolls[] = $payroll;
        }

        return response()->json([
            'message' => 'Payroll generated successfully',
            'count' => count($payrolls)
        ]);
    }

    public function markPaid(Request $request)
    {
        $request->validate([
            'payroll_ids' => 'required|array',
            'payroll_ids.*' => 'exists:payrolls,id'
        ]);

        Payroll::whereIn('id', $request->payroll_ids)
            ->update(['status' => 'paid']);

        return response()->json(['message' => 'Payrolls marked as paid']);
    }
}