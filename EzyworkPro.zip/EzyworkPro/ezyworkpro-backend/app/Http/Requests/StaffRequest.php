<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StaffRequest extends FormRequest
{
    public function authorize()
    {
        // Only admin can manage staff; middleware also applies.
        return true;
    }

    public function rules()
    {
        $id = $this->route('staff') ? $this->route('staff')->id : null;

        return [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id,
            'password' => ($id ? 'nullable' : 'required') . '|string|min:8|confirmed',
            'role' => 'required|in:admin,employee',
            'department_id' => 'nullable|exists:departments,id',
            'hourly_rate' => 'nullable|numeric',
        ];
    }
}
