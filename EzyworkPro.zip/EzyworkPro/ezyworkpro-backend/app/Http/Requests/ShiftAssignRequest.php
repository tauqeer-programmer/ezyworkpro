<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ShiftAssignRequest extends FormRequest
{
    public function authorize()
    {
        return $this->user()->role === 'admin';
    }

    public function rules()
    {
        return [
            'user_ids' => 'required|array',
            'user_ids.*' => 'exists:users,id',
            'date' => 'required|date|after_or_equal:today',
        ];
    }

    public function messages()
    {
        return [
            'user_ids.required' => 'Please select at least one employee',
            'date.after_or_equal' => 'Shift assignment date must be today or in the future',
        ];
    }
}