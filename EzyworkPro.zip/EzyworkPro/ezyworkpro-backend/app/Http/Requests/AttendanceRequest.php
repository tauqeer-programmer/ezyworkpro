<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AttendanceRequest extends FormRequest
{
    public function authorize()
    {
        return $this->user()->role === 'admin';
    }

    public function rules()
    {
        return [
            'user_id' => 'required|exists:users,id',
            'clock_in' => 'required|date',
            'clock_out' => 'nullable|date|after:clock_in',
            'hours' => 'nullable|numeric|min:0',
            'status' => 'required|in:open,closed,missing',
            'date' => 'required|date',
        ];
    }
}