<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LeaveRequest extends FormRequest
{
    public function authorize()
    {
        return true; // Detailed authorization in policy
    }

    public function rules()
    {
        $rules = [
            'type' => 'required|string',
            'start_date' => 'required|date|after_or_equal:today',
            'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'required|string',
        ];

        // Only admin can update status
        if ($this->user()->role === 'admin') {
            $rules['status'] = 'sometimes|in:pending,approved,rejected';
        }

        return $rules;
    }
}