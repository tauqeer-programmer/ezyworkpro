<?php

return [
    'roles' => [
        'admin' => 'admin',
        'employee' => 'employee',
    ],
];
