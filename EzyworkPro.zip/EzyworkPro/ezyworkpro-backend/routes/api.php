<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\StaffController;
use App\Http\Controllers\API\AttendanceController;
use App\Http\Controllers\API\LeaveController;
use App\Http\Controllers\API\ShiftController;
use App\Http\Controllers\API\PayrollController;
use App\Http\Controllers\API\KpiController;
use App\Http\Controllers\API\ReportController;

// Public auth routes
Route::post('register', [AuthController::class, 'register']);
Route::post('login', [AuthController::class, 'login']);
Route::post('password/forgot', [AuthController::class, 'forgotPassword']);

// Protected API (use sanctum or token middleware)
Route::middleware(['auth:sanctum'])->group(function () {
    Route::post('logout', [AuthController::class, 'logout']);

    // Staff management (Admin only)
    Route::apiResource('staff', StaffController::class)->middleware('role:admin');

    // Attendance
    Route::post('attendance/clock-in', [AttendanceController::class, 'clockIn']);
    Route::post('attendance/clock-out', [AttendanceController::class, 'clockOut']);
    Route::get('attendance', [AttendanceController::class, 'index']);

    // Leave
    Route::apiResource('leaves', LeaveController::class);

    // Shifts
    Route::apiResource('shifts', ShiftController::class);

    // Payroll
    Route::get('payrolls', [PayrollController::class, 'index']);
    Route::post('payrolls/run', [PayrollController::class, 'runPayroll'])->middleware('role:admin');

    // KPIs
    Route::apiResource('kpis', KpiController::class);

    // Reports
    Route::get('reports/dashboard', [ReportController::class, 'dashboard'])->middleware('role:admin');
});
