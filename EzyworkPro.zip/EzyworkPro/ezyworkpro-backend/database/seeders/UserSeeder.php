<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run()
    {
        // Create admin user
        User::create([
            'name' => 'System Administrator',
            'email' => 'admin@ezyworkpro.com',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
            'department_id' => 1, // HR Department
            'hourly_rate' => 50.00,
        ]);

        // Create sample employees
        $employees = [
            [
                'name' => 'John Developer',
                'email' => 'john@ezyworkpro.com',
                'department_id' => 2,
                'hourly_rate' => 35.00,
            ],
            [
                'name' => 'Sarah Accountant',
                'email' => 'sarah@ezyworkpro.com',
                'department_id' => 3,
                'hourly_rate' => 30.00,
            ],
            [
                'name' => 'Mike Marketing',
                'email' => 'mike@ezyworkpro.com',
                'department_id' => 4,
                'hourly_rate' => 28.00,
            ],
        ];

        foreach ($employees as $employee) {
            User::create([
                ...$employee,
                'password' => Hash::make('employee123'),
                'role' => 'employee',
            ]);
        }
    }
}