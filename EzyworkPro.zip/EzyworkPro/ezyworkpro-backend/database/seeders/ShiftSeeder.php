<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Shift;

class ShiftSeeder extends Seeder
{
    public function run()
    {
        $shifts = [
            [
                'name' => 'Morning Shift',
                'start_time' => '09:00:00',
                'end_time' => '17:00:00',
                'notes' => 'Regular day shift',
            ],
            [
                'name' => 'Evening Shift',
                'start_time' => '17:00:00',
                'end_time' => '01:00:00',
                'notes' => 'Evening operations',
            ],
            [
                'name' => 'Night Shift',
                'start_time' => '23:00:00',
                'end_time' => '07:00:00',
                'notes' => 'Night operations',
            ],
        ];

        foreach ($shifts as $shift) {
            Shift::create($shift);
        }
    }
}