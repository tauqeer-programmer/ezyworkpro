<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Department;

class DepartmentSeeder extends Seeder
{
    public function run()
    {
        $departments = [
            ['name' => 'Human Resources', 'description' => 'HR department handles employee management'],
            ['name' => 'Information Technology', 'description' => 'IT department handles technical infrastructure'],
            ['name' => 'Finance', 'description' => 'Finance department handles company finances'],
            ['name' => 'Marketing', 'description' => 'Marketing department handles brand and promotion'],
            ['name' => 'Operations', 'description' => 'Operations department handles day-to-day activities'],
        ];

        foreach ($departments as $department) {
            Department::create($department);
        }
    }
}